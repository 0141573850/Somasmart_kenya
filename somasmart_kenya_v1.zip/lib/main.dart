
import 'package:flutter/material.dart';

void main() {
  runApp(const SomaSmartApp());
}

class SomaSmartApp extends StatelessWidget {
  const SomaSmartApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'SomaSmart Kenya',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.green),
        useMaterial3: true,
      ),
      home: const MainScreen(),
    );
  }
}

class MainScreen extends StatefulWidget {
  const MainScreen({super.key});

  @override
  State<MainScreen> createState() => _MainScreenState();
}

class _MainScreenState extends State<MainScreen> {
  int index = 0;

  final pages = const [
    HomePage(),
    SubjectsPage(),
    NotesPage(),
    QuizzesPage(),
    ProfilePage(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: pages[index],
      bottomNavigationBar: NavigationBar(
        selectedIndex: index,
        onDestinationSelected: (value) => setState(() => index = value),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'Home'),
          NavigationDestination(icon: Icon(Icons.menu_book_outlined), selectedIcon: Icon(Icons.menu_book), label: 'Subjects'),
          NavigationDestination(icon: Icon(Icons.note_outlined), selectedIcon: Icon(Icons.note), label: 'Notes'),
          NavigationDestination(icon: Icon(Icons.quiz_outlined), selectedIcon: Icon(Icons.quiz), label: 'Quizzes'),
          NavigationDestination(icon: Icon(Icons.person_outline), selectedIcon: Icon(Icons.person), label: 'Profile'),
        ],
      ),
    );
  }
}

class HomePage extends StatelessWidget {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          const Text('SomaSmart Kenya', style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold)),
          const SizedBox(height: 6),
          Text('Learn smarter. Pass better.', style: TextStyle(color: Colors.grey[700])),
          const SizedBox(height: 24),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(20),
              child: Row(
                children: [
                  const CircleAvatar(radius: 28, child: Icon(Icons.school, size: 30)),
                  const SizedBox(width: 16),
                  const Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('Welcome, Student!', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                        SizedBox(height: 4),
                        Text('Continue your studies today.'),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 18),
          const Text('Quick access', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
          const SizedBox(height: 12),
          _QuickCard(icon: Icons.menu_book, title: 'Subjects', subtitle: 'Browse your subjects'),
          _QuickCard(icon: Icons.note, title: 'Notes', subtitle: 'Read your study notes'),
          _QuickCard(icon: Icons.quiz, title: 'Quizzes', subtitle: 'Test your knowledge'),
        ],
      ),
    );
  }
}

class _QuickCard extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;

  const _QuickCard({required this.icon, required this.title, required this.subtitle});

  @override
  Widget build(BuildContext context) {
    return Card(
      child: ListTile(
        leading: CircleAvatar(child: Icon(icon)),
        title: Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
        subtitle: Text(subtitle),
        trailing: const Icon(Icons.arrow_forward_ios, size: 16),
      ),
    );
  }
}

class SubjectsPage extends StatelessWidget {
  const SubjectsPage({super.key});

  final subjects = const [
    ['Financial Accounting', Icons.account_balance],
    ['Economics', Icons.trending_up],
    ['Computer Studies', Icons.computer],
    ['Academic Writing', Icons.edit_document],
    ['Management', Icons.groups],
    ['Information Literacy', Icons.library_books],
  ];

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          const Text('Subjects', style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold)),
          const SizedBox(height: 16),
          ...subjects.map((s) => Card(
            child: ListTile(
              leading: CircleAvatar(child: Icon(s[1] as IconData)),
              title: Text(s[0] as String, style: const TextStyle(fontWeight: FontWeight.bold)),
              subtitle: const Text('Open subject'),
              trailing: const Icon(Icons.chevron_right),
            ),
          )),
        ],
      ),
    );
  }
}

class NotesPage extends StatelessWidget {
  const NotesPage({super.key});

  final notes = const [
    ['Price Elasticity', 'Economics'],
    ['Ledger Accounts', 'Financial Accounting'],
    ['Operating System', 'Computer Studies'],
    ['Academic Writing', 'Academic Writing'],
  ];

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          const Text('Notes', style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold)),
          const SizedBox(height: 16),
          ...notes.map((n) => Card(
            child: ListTile(
              leading: const Icon(Icons.description),
              title: Text(n[0], style: const TextStyle(fontWeight: FontWeight.bold)),
              subtitle: Text(n[1]),
              trailing: const Icon(Icons.arrow_forward_ios, size: 16),
            ),
          )),
        ],
      ),
    );
  }
}

class QuizzesPage extends StatefulWidget {
  const QuizzesPage({super.key});

  @override
  State<QuizzesPage> createState() => _QuizzesPageState();
}

class _QuizzesPageState extends State<QuizzesPage> {
  int? selected;
  int score = 0;
  bool submitted = false;

  final options = ['Operating System', 'Antivirus', 'Keyboard', 'Monitor'];

  void submit() {
    setState(() {
      submitted = true;
      score = selected == 0 ? 1 : 0;
    });
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          const Text('Quizzes', style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold)),
          const SizedBox(height: 16),
          const Card(
            child: Padding(
              padding: EdgeInsets.all(18),
              child: Text(
                'Which software is the most important software needed to operate a computer?',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              ),
            ),
          ),
          const SizedBox(height: 10),
          ...List.generate(options.length, (i) => RadioListTile<int>(
            value: i,
            groupValue: selected,
            onChanged: submitted ? null : (v) => setState(() => selected = v),
            title: Text(options[i]),
          )),
          const SizedBox(height: 10),
          FilledButton(
            onPressed: selected == null || submitted ? null : submit,
            child: const Text('Submit Answer'),
          ),
          if (submitted) ...[
            const SizedBox(height: 16),
            Card(
              child: Padding(
                padding: const EdgeInsets.all(18),
                child: Text(
                  score == 1 ? 'Correct! Score: 1/1' : 'Not correct. The answer is Operating System.',
                  style: const TextStyle(fontWeight: FontWeight.bold),
                ),
              ),
            ),
          ],
        ],
      ),
    );
  }
}

class ProfilePage extends StatelessWidget {
  const ProfilePage({super.key});

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          const Text('Profile', style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold)),
          const SizedBox(height: 24),
          const Center(child: CircleAvatar(radius: 48, child: Icon(Icons.person, size: 50))),
          const SizedBox(height: 14),
          const Center(child: Text('Student', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold))),
          const SizedBox(height: 28),
          Card(child: ListTile(leading: const Icon(Icons.school), title: const Text('University Student'), subtitle: const Text('SomaSmart Kenya'))),
          Card(child: ListTile(leading: const Icon(Icons.settings), title: const Text('Settings'), trailing: const Icon(Icons.chevron_right))),
          Card(child: ListTile(leading: const Icon(Icons.info_outline), title: const Text('About SomaSmart'), trailing: const Icon(Icons.chevron_right))),
        ],
      ),
    );
  }
}
